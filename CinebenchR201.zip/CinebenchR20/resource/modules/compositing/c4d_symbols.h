enum
{
	// string table definitions
	IDS_COMPOSITING3DTAG = 1000,
// End of symbol definition
	_DUMMY_ELEMENT_
};
