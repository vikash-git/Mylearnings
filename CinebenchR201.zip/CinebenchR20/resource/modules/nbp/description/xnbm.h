#ifndef XNBM_H__
#define XNBM_H__

enum
{
	NBMSHADER_DUMMY = 1000
};

#endif // XNBM_H__
