#ifndef CKMORPH_H__
#define CKMORPH_H__

enum
{
	CID_MORPHKEY_LINK      = 10001,
	CID_MORPHKEY_BIAS      = 10002,
	CID_MORPHKEY_CUBIC     = 10003
};

#endif // CKMORPH_H__
