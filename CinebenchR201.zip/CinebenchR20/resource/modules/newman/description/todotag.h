#ifndef TODOTAG_H__
#define TODOTAG_H__

enum
{
	TODOTAG_TEXT 			= 1001,
	TODOTAG_DONE			= 1002,
	TODOTAG_SELECT		= 1003,
	TODOTAG_CHECKED		= 1004,

};

#endif // TODOTAG_H__
