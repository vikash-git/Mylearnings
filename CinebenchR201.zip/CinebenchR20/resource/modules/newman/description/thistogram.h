#ifndef THISTOGRAM_H__
#define THISTOGRAM_H__

enum
{
	HISTOGRAM_PROPERTIES = 1000,
	HISTOGRAM_IMAGE,		// Image
	HISTOGRAM_RED,			//Bool
	HISTOGRAM_GREEN,		//Bool
	HISTOGRAM_BLUE,			//Bool
	HISTOGRAM_LUMA			//Bool






};

#endif // THISTOGRAM_H__
