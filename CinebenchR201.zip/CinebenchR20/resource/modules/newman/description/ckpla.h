#ifndef CKPLA_H__
#define CKPLA_H__

enum
{
	CK_PLA_BIAS  = 10001, // real
	CK_PLA_CUBIC = 10002, // bool
	CK_PLA_DATA  = 10003,

	CK_PLA_DUMMY
};

#endif // CKPLA_H__
