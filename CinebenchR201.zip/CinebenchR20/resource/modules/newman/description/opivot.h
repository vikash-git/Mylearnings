#ifndef OPIVOT_H__
#define OPIVOT_H__

enum
{
	OPIVOT_RAD	 = 10000, // real

	// internal
	OPIVOT_OFF   = 10005, // matrix

	_OPIVOT
};

#endif // OPIVOT_H__
