#ifndef XRUST_H__
#define XRUST_H__

enum
{
	RUSTSHADER_LEVEL			= 1002,	 // REAL
	RUSTSHADER_FREQUENCY	= 1004,	 // REAL
	RUSTSHADER_COLOR			= 1005   // GRADIENT
};

#endif // XRUST_H__
