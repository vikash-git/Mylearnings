#ifndef XOBJECTCOLOR_H__
#define XOBJECTCOLOR_H__

enum
{
	
};

#endif // XOBJECTCOLOR_H__
