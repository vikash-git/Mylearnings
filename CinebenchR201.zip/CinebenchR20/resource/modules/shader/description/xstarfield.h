#ifndef XSTARFIELD_H__
#define XSTARFIELD_H__

enum
{
	STARFIELDSHADER_DUMMY
};

#endif // XSTARFIELD_H__
