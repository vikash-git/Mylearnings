#ifndef XMETAL_H__
#define XMETAL_H__

enum
{
	METALSHADER_FREQUENCY	= 1002,	 // REAL
	METALSHADER_COLOR 		= 1005   // GRADIENT
};

#endif // XMETAL_H__
