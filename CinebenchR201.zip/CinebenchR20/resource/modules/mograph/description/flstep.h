#ifndef FLSTEP_H__
#define FLSTEP_H__

enum
{
	FIELDLAYER_STEP_MODE_DEPRECATED = 1000,	// Int Cycle
};
#endif	// FLSTEP_H__
