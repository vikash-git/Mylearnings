#ifndef XMG_FALLOFF_H__
#define XMG_FALLOFF_H__

enum
{
	MGFALLOFFSHADER_LIST = 1000
};
#endif	// XMG_FALLOFF_H__
