#ifndef OESOUND_H__
#define OESOUND_H__

enum
{
	MGSOUNDEFFECTOR_GADGET				= 1100
};
#endif // OESOUND_H__
