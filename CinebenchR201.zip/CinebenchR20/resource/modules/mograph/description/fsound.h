#ifndef FSOUND_H__
#define FSOUND_H__

enum
{
	MGSOUNDFIELD_GADGET = 1100
};
#endif	// FSOUND_H__
