#ifndef MGPOLYAXIS_H__
#define MGPOLYAXIS_H__

enum
{
	MGPOLYAXISDUMMY
};
#endif // MGPOLYAXIS_H__
