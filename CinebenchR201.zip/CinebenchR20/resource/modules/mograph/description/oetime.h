#ifndef OETIME_H__
#define OETIME_H__

enum
{
	OETIMEDUMMY
};
#endif // OETIME_H__
