#ifndef OEPLAIN_H__
#define OEPLAIN_H__

enum
{
	OEPLAINDUMMY
};
#endif // OEPLAIN_H__
