#ifndef OESHADER_H__
#define OESHADER_H__

enum
{
	_OEFFECTOR_DUMMY
};
#endif // OESHADER_H__
