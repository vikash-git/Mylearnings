#ifndef MGPOLYPOLYGON_H__
#define MGPOLYPOLYGON_H__

enum
{
	MG_POLYPOLYGON_GROUP = 1099
};
#endif // MGPOLYPOLYGON_H__
