#ifndef OFALLOFF_H_
#define OFALLOFF_H_

enum
{
	DUMMY_
};
#endif	// OFALLOFF_H_
