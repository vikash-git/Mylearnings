#ifndef MGTP_H__
#define MGTP_H__

enum
{
	MG_TP_STRETCH				= 1050,
	MG_TP_SCALE					= 1051,
	MG_TP_USESUBGROUPS	= 1052,
	MG_TP_TYPE					= 1053,
	MG_TP_TYPE_STANDARD = 0,
	MG_TP_TYPE_STRETCH	= 1
};
#endif // MGTP_H__
