#ifndef FGROUP_H__
#define FGROUP_H__

enum
{
	// Falloff controls
	FIELDGROUP_FIELDS	=	1000	// FieldList
};
#endif											// FGROUP_H__
