#ifndef MGPOLYVERTEX_H__
#define MGPOLYVERTEX_H__

enum
{
	MGPOLYVERTEXDUMMY
};
#endif // MGPOLYVERTEX_H__
