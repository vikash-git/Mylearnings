#ifndef TOOLHAIRTRIMMER_H__
#define TOOLHAIRTRIMMER_H__

enum
{
	//////////////////////////////////////////////////////////////////////////

	HAIR_TOOL_TRIMMER_DUMMY
};

#endif // TOOLHAIRTRIMMER_H__
