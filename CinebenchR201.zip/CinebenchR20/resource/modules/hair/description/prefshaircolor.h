#ifndef PREFSHAIRCOLOR_H__
#define PREFSHAIRCOLOR_H__

//3000 because with 1000 conflict with other hair prefs
enum
{
	PREF_HAIRCOLOR_MAIN_GROUP = 999,
	PREF_HAIRCOLOR_COLORS	= 3000,
	PREF_HAIRCOLOR_LIST		= 3001,

	PREF_HAIRCOLOR_DUMMY
};

#endif // PREFSHAIRCOLOR_H__
