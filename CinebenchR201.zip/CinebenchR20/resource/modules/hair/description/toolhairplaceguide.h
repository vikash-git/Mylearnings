#ifndef TOOLHAIRPLACEGUIDE_H__
#define TOOLHAIRPLACEGUIDE_H__

enum
{
	//////////////////////////////////////////////////////////////////////////

	HAIR_TOOL_PLACE_GUIDE_DUMMY
};

#endif // TOOLHAIRPLACEGUIDE_H__
