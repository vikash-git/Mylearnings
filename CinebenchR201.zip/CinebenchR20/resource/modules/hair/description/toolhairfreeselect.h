#ifndef TOOLHAIRFREESELECT_H__
#define TOOLHAIRFREESELECT_H__

enum
{
	//////////////////////////////////////////////////////////////////////////

	HAIR_FREESELECT_DUMMY
};

#endif // TOOLHAIRFREESELECT_H__
