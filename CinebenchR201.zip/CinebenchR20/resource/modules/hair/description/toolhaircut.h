#ifndef TOOLHAIRCUT_H__
#define TOOLHAIRCUT_H__

enum
{
	HAIR_TOOL_CUT_LINK = 2000,
	HAIR_TOOL_CUT_APPLY,
	HAIR_TOOL_CUT_LENGTH,
	HAIR_TOOL_CUT_SELECTED,

	//////////////////////////////////////////////////////////////////////////

	HAIR_TOOL_CUT_DUMMY
};

#endif // TOOLHAIRCUT_H__
