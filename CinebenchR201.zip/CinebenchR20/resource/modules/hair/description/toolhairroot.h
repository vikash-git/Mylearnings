#ifndef TOOLHAIRROOT_H__
#define TOOLHAIRROOT_H__

enum
{
	HAIR_TOOL_ROOT_DISTANCE = 1001,
	HAIR_TOOL_ROOT_CHECK_TIPS,
	HAIR_TOOL_ROOT_ALIGN_ROOT,

	//////////////////////////////////////////////////////////////////////////

	HAIR_TOOL_ROOT_DUMMY
};

#endif // TOOLHAIRROOT_H__
