#ifndef TOOLHAIRMOVE_H__
#define TOOLHAIRMOVE_H__

enum
{
	HAIR_MOVE_IK = 1000,
	HAIR_MOVE_COLLISIONS,
	HAIR_MOVE_RADIUS,

	//////////////////////////////////////////////////////////////////////////

	HAIR_MOVE_DUMMY
};

#endif // TOOLHAIRMOVE_H__
