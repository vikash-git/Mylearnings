#ifndef TOOLHAIRRECTSELECT_H__
#define TOOLHAIRRECTSELECT_H__

enum
{
	//////////////////////////////////////////////////////////////////////////

	HAIR_RECTSELECT_DUMMY
};

#endif // TOOLHAIRRECTSELECT_H__
