#ifndef TOOLHAIRGROWSELECTION_H__
#define TOOLHAIRGROWSELECTION_H__

enum
{
	HAIR_GROWSELECTION_DISTANCE = 1000,
	HAIR_GROWSELECTION_NEIGHBORS,

	//////////////////////////////////////////////////////////////////////////

	HAIR_GROWSELECTION_DUMMY
};

#endif // TOOLHAIRGROWSELECTION_H__
