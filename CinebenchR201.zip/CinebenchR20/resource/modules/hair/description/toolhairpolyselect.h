#ifndef TOOLHAIRPOLYSELECT_H__
#define TOOLHAIRPOLYSELECT_H__

enum
{
	//////////////////////////////////////////////////////////////////////////

	HAIR_POLYSELECT_DUMMY
};

#endif // TOOLHAIRPOLYSELECT_H__
