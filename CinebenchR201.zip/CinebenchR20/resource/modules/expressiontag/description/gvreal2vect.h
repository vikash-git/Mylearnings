#ifndef GVREAL2VECT_H__
#define GVREAL2VECT_H__

#include "gvbase.h"

enum
{
	GV_REAL2VECT_INPUT_X						= 2000,
	GV_REAL2VECT_INPUT_Y						= 2001,
	GV_REAL2VECT_INPUT_Z						= 2002,

	GV_REAL2VECT_OUTPUT_VECTOR			= 3000,

	GV_REAL2VECT_
};

#endif // GVREAL2VECT_H__
