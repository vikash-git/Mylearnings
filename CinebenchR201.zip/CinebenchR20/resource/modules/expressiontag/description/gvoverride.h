#ifndef GVOVERRIDE_H__
#define GVOVERRIDE_H__

#include "gvdynamic.h"

enum
{
	GV_OVERRIDE_INPUT_MAIN		= 1999,
	GV_OVERRIDE_INPUT					= 2000,
	GV_OVERRIDE_OUTPUT_NAME		= 2999,
	GV_OVERRIDE_OUTPUT				= 3000,
};

#endif // GVOVERRIDE_H__
