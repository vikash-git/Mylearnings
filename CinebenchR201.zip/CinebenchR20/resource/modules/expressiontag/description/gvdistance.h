#ifndef GVDISTANCE_H__
#define GVDISTANCE_H__

#include "gvbase.h"

enum
{
	GV_DISTANCE_INPUT1	= 2000,
	GV_DISTANCE_INPUT2	= 2001,
	GV_DISTANCE_OUTPUT	= 3000,

	GV_DISTANCE_
};

#endif // GVDISTANCE_H__
