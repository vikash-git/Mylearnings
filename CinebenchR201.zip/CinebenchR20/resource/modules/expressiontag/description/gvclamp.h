#ifndef GVCLAMP_H__
#define GVCLAMP_H__

#include "gvdynamic.h"

enum
{
	GV_CLAMP_INPUT1					= 2000,
	GV_CLAMP_INPUT2					= 2001,
	GV_CLAMP_INPUT3					= 2002,

	GV_CLAMP_OUTPUT					= 3000,

	GV_CLAMP_
};

#endif // GVCLAMP_H__
