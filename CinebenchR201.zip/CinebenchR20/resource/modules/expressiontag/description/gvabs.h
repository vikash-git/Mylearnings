#ifndef GVABS_H__
#define GVABS_H__

#include "gvdynamic.h"

enum
{
	GV_ABS_INPUT					= 2000,
	GV_ABS_OUTPUT					= 3000,

	GV_ABS_
};

#endif // GVABS_H__
