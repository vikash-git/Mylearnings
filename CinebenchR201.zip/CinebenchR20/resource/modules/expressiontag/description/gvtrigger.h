#ifndef GVTRIGGER_H__
#define GVTRIGGER_H__

#include "gvbase.h"

enum
{
	GV_TRIGGER_ON = 1000,
	GV_TRIGGER_SWITCH,
	GV_TRIGGER_OFF,

	GV_TRIGGER_OUT = 2000,

	GV_TRIGGER_
};

#endif // GVTRIGGER_H__
