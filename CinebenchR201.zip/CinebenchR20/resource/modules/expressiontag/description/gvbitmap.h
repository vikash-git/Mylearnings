#ifndef GVBITMAP_H__
#define GVBITMAP_H__

#include "gvbase.h"

enum
{
	GV_BITMAP_X					 = 1001,
	GV_BITMAP_Y,
	GV_BITMAP_WIDTH,
	GV_BITMAP_HEIGHT,
	GV_BITMAP_COLOR,
	GV_BITMAP_FN_PORT,


	GV_BITMAP_
};

#endif // GVBITMAP_H__
