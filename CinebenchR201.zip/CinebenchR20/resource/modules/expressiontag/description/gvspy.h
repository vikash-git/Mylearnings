#ifndef GVSPY_H__
#define GVSPY_H__

#include "gvdynamic.h"

enum
{
	GV_SPY_INPUT			= 2000,
	GV_SPY_OUTPUT			= 3000,

	GV_SPY_
};

#endif // GVSPY_H__
