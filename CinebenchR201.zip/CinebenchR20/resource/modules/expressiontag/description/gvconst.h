#ifndef GVCONST_H__
#define GVCONST_H__

#include "gvdynamic.h"

enum
{
	GV_CONST_VALUE = 1000,
	GV_CONSTANT_DEFAULT,
	GV_CONST_OUTPUT	= 3000,

	GV_CONST_
};

#endif // GVCONST_H__
