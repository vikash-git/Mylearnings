#ifndef GVFREEZE_H__
#define GVFREEZE_H__

#include "gvdynamic.h"

enum
{
	GV_FREEZE_INPUTSWITCH		= 2000,
	GV_FREEZE_INPUTVALUE		= 2001,
	GV_FREEZE_OUTPUT				= 3000,

	GV_FREEZE_
};

#endif // GVFREEZE_H__
