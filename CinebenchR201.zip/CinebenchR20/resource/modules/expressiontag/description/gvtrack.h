#ifndef GVTRACK_H__
#define GVTRACK_H__

#include "gvbase.h"

enum
{
	GV_TRACK_LINK								= 1000,
	GV_TRACK_INPUT_TIME					= 2000,
	GV_TRACK_OUTPUT_VALUE				= 3000,

	GV_TRACK_
};

#endif // GVTRACK_H__
