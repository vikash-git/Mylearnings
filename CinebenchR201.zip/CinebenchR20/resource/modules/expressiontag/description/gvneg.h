#ifndef GVNEG_H__
#define GVNEG_H__

#include "gvdynamic.h"

enum
{
	GV_NEG_INPUT								= 2000,
	GV_NEG_OUTPUT								= 3000,

	GV_NEG_
};

#endif // GVNEG_H__
