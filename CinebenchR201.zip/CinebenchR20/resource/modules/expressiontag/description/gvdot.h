#ifndef GVDOT_H__
#define GVDOT_H__

#include "gvdynamic.h"

enum
{
	GV_DOT_INPUT1	= 2000,
	GV_DOT_INPUT2	= 2001,
	GV_DOT_OUTPUT	= 3000,

	GV_DOT_
};

#endif // GVDOT_H__
