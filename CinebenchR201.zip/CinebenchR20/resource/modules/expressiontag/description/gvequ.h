#ifndef GVEQU_H__
#define GVEQU_H__

#include "gvdynamic.h"

enum
{
	GV_EQU_NEGATE		= 1000,
	GV_EQU_INPUT		= 2000,
	GV_EQU_OUTPUT		= 3000,

	GV_EQU_
};

#endif // GVEQU_H__
