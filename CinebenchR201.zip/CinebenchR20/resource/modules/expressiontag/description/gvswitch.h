#ifndef GVSWITCH_H__
#define GVSWITCH_H__

#include "gvbase.h"

enum
{
	GV_SWITCH_VAL 				= 1000,
		GV_FALSE_NODE_FUNCTION 	= 0,
		GV_TRUE_NODE_FUNCTION		= 1,
	GV_SWITCH_OUTPUT			= 3000,

	GV_SWITCH_
};

#endif // GVSWITCH_H__
