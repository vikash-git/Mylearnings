#ifndef TQUATERNION_H__
#define TQUATERNION_H__

enum
{
	QUAT_INTER   = 1001,
		INTER_SLERP,
		INTER_SQUAD,
		INTER_LOSCH,

	QUAT_DUMY
};

#endif // TQUATERNION_H__

