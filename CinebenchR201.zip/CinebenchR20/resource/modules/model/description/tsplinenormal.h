#ifndef TSPLINENORMAL_H__
#define TSPLINENORMAL_H__

enum
{
	SPLINENORMAL_DUMMY___			=	 0		//Dummy element
};
#endif // TSPLINENORMAL_H__
