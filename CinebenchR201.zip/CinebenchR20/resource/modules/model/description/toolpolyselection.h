#ifndef TOOLPOLYSELECTION_H__
#define TOOLPOLYSELECTION_H__

#include "toolmodelingaxis.h"

enum
{
	MDATA_SELECTPOLY_
};

#endif // TOOLPOLYSELECTION_H__
