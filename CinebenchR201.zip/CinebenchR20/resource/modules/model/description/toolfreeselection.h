#ifndef TOOLFREESELECTION_H__
#define TOOLFREESELECTION_H__

#include "toolmodelingaxis.h"

enum
{
	MDATA_SELECTFREE_
};

#endif // TOOLFREESELECTION_H__
