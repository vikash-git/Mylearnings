#ifndef TOOLROTATE_H__
#define TOOLROTATE_H__

#include "toolmodelingaxis.h"

enum
{
	MDATA_MODELING_ROTATE_
};

#endif // TOOLROTATE_H__
