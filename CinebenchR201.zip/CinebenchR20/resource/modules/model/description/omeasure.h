#ifndef OMEASURE_H__
#define OMEASURE_H__

#include "toolmeasure.h"

#endif // OMEASURE_H__
