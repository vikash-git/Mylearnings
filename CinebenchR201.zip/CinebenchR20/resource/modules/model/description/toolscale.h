#ifndef TOOLSCALE_H__
#define TOOLSCALE_H__

#include "toolmodelingaxis.h"

enum
{
	MDATA_MODELING_SCALE_
};

#endif // TOOLSCALE_H__
