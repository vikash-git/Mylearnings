#ifndef TOOLSPLINECHAMFER_H__
#define TOOLSPLINECHAMFER_H__

enum
{
	MDATA_SPLINE_CHAMFERFLAT	 = 2017,	// bool : Flat Rounding
	MDATA_SPLINE_CHAMFERRADIUS = 2018		// real : Radius
};

#endif	// TOOLSPLINECHAMFER_H__
