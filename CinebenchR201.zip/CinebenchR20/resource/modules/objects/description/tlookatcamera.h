#ifndef TLOOKATCAMERA_H__
#define TLOOKATCAMERA_H__

enum
{
	LOOKATCAMERA_PITCH				= 1000
};

#endif // TLOOKATCAMERA_H__



