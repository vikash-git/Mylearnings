#ifndef TSDS_H__
#define TSDS_H__

enum
{
	SDSTAG_SUBEDITOR              = 1100,   // LONG
	SDSTAG_SUBRAY                 = 1101,   // LONG
	SDSTAG_USE_SDS_STEPS          = 1102,  	// Bool
};

#endif // TSDS_H__
