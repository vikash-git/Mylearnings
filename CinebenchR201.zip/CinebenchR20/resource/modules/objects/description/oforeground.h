#ifndef OFOREGROUND_H__
#define OFOREGROUND_H__

enum
{
	OFOREGROUND_DUMMY
};

#endif // OFOREGROUND_H__
