#ifndef OTWIST_H__
#define OTWIST_H__

enum
{
	OTWIST_DUMMY
};

#endif // OTWIST_H__
