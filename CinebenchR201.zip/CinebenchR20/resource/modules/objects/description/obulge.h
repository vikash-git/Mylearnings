#ifndef OBULGE_H__
#define OBULGE_H__

enum
{
	OBULGE_DUMMY
};

#endif // OBULGE_H__
