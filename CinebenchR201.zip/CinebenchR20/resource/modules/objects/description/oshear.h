#ifndef OSHEAR_H__
#define OSHEAR_H__

enum
{
	OSHEAR_DUMMY
};

#endif // OSHEAR_H__
