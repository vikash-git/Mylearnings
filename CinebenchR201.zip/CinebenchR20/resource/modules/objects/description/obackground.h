#ifndef OBACKGROUND_H__
#define OBACKGROUND_H__

enum
{
	OBACKGROUND_DUMMY
};

#endif // OBACKGROUND_H__
