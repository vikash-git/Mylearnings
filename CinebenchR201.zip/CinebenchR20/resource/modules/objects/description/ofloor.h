#ifndef OFLOOR_H__
#define OFLOOR_H__

enum
{
	OFLOOR_DUMMY
};

#endif // OFLOOR_H__
