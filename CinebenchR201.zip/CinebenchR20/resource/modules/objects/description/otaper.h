#ifndef OTAPER_H__
#define OTAPER_H__

enum
{
	OTAPER_DUMMY
};

#endif // OTAPER_H__
