#ifndef FSTLEXPORT_H__
#define FSTLEXPORT_H__

enum
{
	STLEXPORTFILTER_GROUP						= 999,
	STLEXPORTFILTER_SCALE		 				= 2000
};

#endif // FSTLEXPORT_H__
